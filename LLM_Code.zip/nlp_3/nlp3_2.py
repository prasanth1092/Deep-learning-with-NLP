import pickle
import glob
from mp3_release.scripts.utils import get_files,convert_files2idx,convert_line2idx
import numpy as np
import torch
torch.manual_seed(42)
from torch.utils.data import TensorDataset, DataLoader
from tqdm import tqdm
import pandas as pd
import math
import copy

with open ("./mp3_release/data/vocab.pkl" , 'rb') as f:
    vocab = pickle.load (f)

rev_vocab = {v:k for k,v in vocab.items()}   

train_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/train")
dev_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/dev")
test_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/test")

train_data = convert_files2idx(train_file_list,vocab)
dev_data = convert_files2idx(dev_file_list,vocab)
test_data = convert_files2idx(test_file_list,vocab)



def length(train_data):
  train_len = 0
  for i in range(len(train_data)):
    for j in range(len(train_data[i])):
      train_len = train_len + 1
  return train_len

train_len = length(train_data)
dev_len = length(dev_data)
test_len = length(test_data)
       

weight_list = [0]*386
for i in range(len(train_data)):
  for j in range(len(train_data[i])):
    weight_list[train_data[i][j]] += 1

total = sum(weight_list)
for i in range(len(weight_list)):
  weight_list[i]=1-(weight_list[i]/total)

def padding(train_data):
  for i in range(len(train_data)):
      if len(train_data[i])%500 != 0 :
        k = len(train_data[i])
        while(k % 500 != 0):
          train_data[i].append(384)
          k = k + 1

padding(train_data)
padding(dev_data)
padding(test_data)                

def final_data(train_data):
  train_list =[]
  for i in range(len(train_data)):
    k = 0
    for j in range(len(train_data[i])):
      if (j % 500 == 499):
        train_list.append(train_data[i][k:j+1])
        k = j + 1
  return train_list 
     
train_list = final_data(train_data)
dev_list = final_data(dev_data)
test_list = final_data(test_data)

def final_labels_data(train_list):
  train_lab_list = copy.deepcopy(train_list)
  for i in range(len(train_lab_list)):
    for j in range(len(train_lab_list[i])):
      if(j < 499):
        train_lab_list[i][j] = train_list[i][j+1]
      else:
        train_lab_list[i][j] = 384
  return train_lab_list

train_lab_list = final_labels_data(train_list)
dev_lab_list = final_labels_data(dev_list)
test_lab_list = final_labels_data(test_list)             


lay = 2
batch = 64


class MLP(torch.nn.Module):
  def __init__(self,vocab_len, lstm_len,input_dim, hid_dim):
    super().__init__()
    self.embed = torch.nn.Embedding(vocab_len, input_dim)        
    self.lstm = torch.nn.LSTM(input_size= input_dim, hidden_size = hid_dim,num_layers=lay,batch_first=True)
    self.l1 = torch.nn.Linear(hid_dim, vocab_len,bias = True) 
    self.l2 = torch.nn.Linear(vocab_len, vocab_len,bias = True)
    self.re = torch.nn.ReLU()
  def forward(self, inp,h,c):
    x , y = self.lstm(self.embed(inp),(h,c))
    z = self.l2(self.re(self.l1(x)))
    return z,y


device = torch.device(f"cuda" if torch.cuda.is_available() else "cpu")
model = MLP(vocab_len =386, lstm_len= 500, input_dim=50,hid_dim=200).to(device)



train_dataset = TensorDataset(
                          torch.tensor(train_list, dtype = torch.int64),
                          torch.tensor(train_lab_list, dtype = torch.int64))
dev_dataset = TensorDataset(
                          torch.tensor(dev_list, dtype = torch.int64),
                          torch.tensor(dev_lab_list,dtype = torch.int64))
test_dataset = TensorDataset(
                          torch.tensor(test_list, dtype = torch.int64),
                          torch.tensor(test_lab_list,dtype = torch.int64))                                                    


train_loader = DataLoader(train_dataset, batch_size=batch, shuffle=True,drop_last = True)
dev_loader = DataLoader(dev_dataset, batch_size=batch,drop_last = True)
test_loader = DataLoader(test_dataset, batch_size=batch,drop_last = True)
loss_fn = torch.nn.CrossEntropyLoss(weight = torch.tensor(weight_list).to(device),ignore_index = 384)
loss_fn1 = torch.nn.CrossEntropyLoss(ignore_index = 384)
optimizer = torch.optim.Adam(model.parameters(), lr= 0.00001)

max_epochs = 5

best_perf_dict = {"metric": 10000, "epoch": 0}

for ep in range(1, max_epochs+1):
    print(f"\nEpoch {ep}")
    train_loss = []      
    for inp, lab in tqdm(train_loader):
        model.train()
        optimizer.zero_grad()

        initial_h = torch.zeros(lay, batch, 200).to(device)
        initial_c = torch.zeros(lay, batch, 200).to(device)
        out,y = model(inp.to(device),initial_h,initial_c)  
      
        a = torch.flatten(out,start_dim=0, end_dim=1)
        b = torch.flatten(lab.to(device),start_dim=0,end_dim=1)
        loss = loss_fn(a,b)

        loss.backward() 
        optimizer.step()

        train_loss.append(loss.cpu().item())

    total_loss = np.sum(np.exp(np.asarray(train_loss)))/len(train_loss)
    print(f"Average perprexity: {total_loss}")
    
    # Evaluation Loop
    batch_loss =[]
    for inp, lab in tqdm(dev_loader):
        model.eval()
        with torch.no_grad():
            initial_h = torch.zeros(lay, batch, 200).to(device)
            initial_c = torch.zeros(lay, batch, 200).to(device)
            out,y = model(inp.to(device),initial_h,initial_c)
            a = torch.flatten(out,start_dim=0, end_dim=1)
            b = torch.flatten(lab.to(device),start_dim=0,end_dim=1)
            batch_loss.append(loss_fn1(a,b).cpu().item())
    px = np.sum(np.exp(np.asarray(batch_loss)))/len(batch_loss)
    print(f"Dev-Perprexity: {px}\n")
    if px < best_perf_dict["metric"]:
        best_perf_dict["metric"] = px
        best_perf_dict["epoch"]  = ep
        torch.save({
            "model_param": model.state_dict(),
            "optim_param": optimizer.state_dict(),
            "dev_metric": px,
            "epoch": ep
        }, f"/scratch/general/vast/u1369444/cs6957/assignment3/{lay}/models/{ep}")

best_epoch = best_perf_dict["epoch"]
model_path = f"/scratch/general/vast/u1369444/cs6957/assignment3/{lay}/models/{best_epoch}"
checkpoint = torch.load(model_path)

model.load_state_dict(checkpoint["model_param"])
optimizer.load_state_dict(checkpoint["optim_param"])


batch_loss =[]
for inp, lab in tqdm(test_loader):
    model.eval()
    with torch.no_grad():
        initial_h = torch.zeros(lay, batch, 200).to(device)
        initial_c = torch.zeros(lay, batch, 200).to(device)
        out,y = model(inp.to(device), initial_h, initial_c)
        a = torch.flatten(out,start_dim=0, end_dim=1)
        b = torch.flatten(lab.to(device),start_dim=0,end_dim=1)
        batch_loss.append(loss_fn1(a,b).cpu().item())

px = np.sum(np.exp(np.asarray(batch_loss)))/len(batch_loss) 
print(f"Test-Perprexity: {px}\n")



pred_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/pred")
pred_data = convert_files2idx(pred_list,vocab)


for i in range(5):
  inp =torch.tensor([pred_data[i]])
  model.eval()
  initial_h = torch.zeros(lay, 1, 200).to(device)
  initial_c = torch.zeros(lay, 1, 200).to(device)
  with torch.no_grad():
          out,y = model(inp.to(device),initial_h,initial_c)
          a = torch.flatten(out,start_dim=0, end_dim=1)    
          for j in range(480):
            inp = torch.tensor([[pred_data[i][-1]]])
            out,y = model(inp.to(device),y[0],y[1])
            a = torch.exp(torch.flatten(out,start_dim=0, end_dim=2))
            # print(a)
            pred_index = torch.multinomial(a,1,replacement=True)
            pred_data[i].append(pred_index[0].cpu().item())

for i in range(len(pred_data)):
   s = ""
   for j in range(len(pred_data[i])):
      s = s + rev_vocab[pred_data[i][j]]
   print(s)
   print("\n")

   num_param = sum(p.numel() for p in model.parameters())

print("Number of paramenters",num_param)  