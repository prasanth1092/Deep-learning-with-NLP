#!/bin/bash
#SBATCH --account soc-gpu-np
#SBATCH --partition soc-gpu-np
#SBATCH --ntasks-per-node=16
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --time=2:00:00
#SBATCH --mem=32GB
#SBATCH -o assignment_3-%j
#SBATCH --export=ALL
source ~/miniconda3/etc/profile.d/conda.sh
conda activate prasanth
OUT_DIR=/scratch/general/vast/u1369444/cs6957/assignment3/2/models
mkdir -p ${OUT_DIR}
python nlp3_2.py --output_dir ${OUT_DIR}