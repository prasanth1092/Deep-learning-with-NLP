import pickle
import glob
from mp3_release.scripts.utils import get_files,convert_files2idx,convert_line2idx
import numpy as np
import torch
torch.manual_seed(42)
from torch.utils.data import TensorDataset, DataLoader
from tqdm import tqdm
import pandas as pd
import math

with open ("./mp3_release/data/vocab.pkl" , 'rb') as f:
    vocab = pickle.load (f)
rev_vocab = {v:k for k,v in vocab.items()}    

train_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/train")
dev_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/dev")
test_file_list = get_files("/uufs/chpc.utah.edu/common/home/u1369444/nlp_3/mp3_release/data/test")

train_data = convert_files2idx(train_file_list,vocab)
# print(train_data)
test_data = convert_files2idx(test_file_list,vocab)
train_dict ={}
for i in range(len(train_data)):
    if(len(train_data[i])>3):
        for j in range(3,len(train_data[i])):
            temp = rev_vocab[train_data[i][j-3]]+rev_vocab[train_data[i][j-2]]+rev_vocab[train_data[i][j-1]]
            if temp in train_dict:
                train_dict[temp][train_data[i][j]] += 1
            else:
                train_dict[temp] = np.ones(386)
print("length of dictionary:",len(train_dict))

for key in train_dict.keys():
    val = sum(train_dict[key])
    for i in range(len(train_dict[key])):
        train_dict[key][i] = train_dict[key][i]/val


plex = []
for i in range(len(test_data)):
    l = len(test_data[i])
    if(l>3):
        p = 0
        for j in range(3,len(test_data[i])):
            temp = rev_vocab[test_data[i][j-3]]+rev_vocab[test_data[i][j-2]]+rev_vocab[test_data[i][j-1]]
            if temp in train_dict:
                p = p - math.log(train_dict[temp][test_data[i][j]],2)
            else:
                p = p - math.log(1/386,2)
        p = p/(l-3)
        plex.append(pow(2,p))

perp = sum(plex)/len(plex)       
print(perp)             



            