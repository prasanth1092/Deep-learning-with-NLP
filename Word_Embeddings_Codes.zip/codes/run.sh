#!/bin/bash
#SBATCH --account soc-gpu-np
#SBATCH --partition soc-gpu-np
#SBATCH --ntasks-per-node=16
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --time=0:10:00
#SBATCH --mem=16GB
#SBATCH -o assignment_1-%j
#SBATCH --export=ALL
source ~/miniconda3/etc/profile.d/conda.sh
conda activate prasanth
OUT_DIR=/scratch/general/vast/u1369444/cs6957/assignment1/models
mkdir -p ${OUT_DIR}
python nlp_1.py --output_dir ${OUT_DIR} 
python assignment1/scripts/eval_embs.py --emb_file "/scratch/general/vast/u1369444/cs6957/assignment1/models/embeddings.txt"