import argparse
import math
import matplotlib.pyplot as plt
parser = argparse.ArgumentParser()
parser.add_argument('--output_dir', type=str, help='Directory where model checkpoints will be saved')
args = parser.parse_args()
output_dir = args.output_dir


import torch
from torch.utils.data import TensorDataset, DataLoader
from tqdm import tqdm
import numpy as np
import pandas as pd
from assignment1.scripts.utils import get_word2ix,get_files,process_data
from sklearn.metrics import f1_score
torch.manual_seed(42) 


word2ix={}
word2ix = get_word2ix("./assignment1/vocab.txt")
train_files=get_files("./assignment1/data/train")
train_data = process_data(train_files, 5, word2ix)
dev_files=get_files("./assignment1/data/dev")
dev_data = process_data(dev_files, 5, word2ix)


training_list=[]
label_list=[]
for i in range(len(train_data)):
  for j in range(5,len(train_data[i])-5):
    temp = []
    for k in range(-5,6):
      if(k!=0):
        temp.append(train_data[i][j+k])
    training_list.append(temp.copy())
    label_list.append(train_data[i][j])
dev_list=[]
dev_label_list=[]
for i in range(len(dev_data)):
  for j in range(5,len(dev_data[i])-5):
    temp = []
    for k in range(-5,6):
      if(k!=0):
        temp.append(dev_data[i][j+k])
    dev_list.append(temp.copy())
    dev_label_list.append(dev_data[i][j])


class MLP(torch.nn.Module):
  def __init__(self,vocab_len, hid_dim, out_dim):
    """ This is the constructor. Initialize your network
    layers here.
    Inputs
    --------
    in_dim: int. Dimension of your input. It was 2 in the example
    hid_dim: int. Dimension of the intermediate level. Also 2 in the example
    out_dim: int. Dimension of your output. It was 1 in the example
    """
    super().__init__()
    self.embed = torch.nn.Embedding(vocab_len, hid_dim)        # Invoke the constructor of the parent class
    self.w = torch.nn.Linear(hid_dim, out_dim)

  def forward(self, inp):
    """ Method for forward pass
    Input
    -------
    inp: torch.Tensor. The dimension of the input (i.e, the last number in shape)
        should match `in_dim`. The shape should be (n,in_dim) where n is the batch size

    Output
    ------
    z: torch.Tensor. The result of the forward pass. The dimension of the output
     (i.e, the last number in shape) should match `out_dim`. The shape should be
     (n, out_dim) where n is the batch size.
    """
    z = self.w(torch.sum(self.embed(inp),dim=1))
    return z

device = torch.device(f"cuda" if torch.cuda.is_available() else "cpu")
model = MLP(vocab_len =18061, hid_dim=100, out_dim=18061).to(device)


train_dataset = TensorDataset(
                          torch.tensor(training_list, dtype = torch.int),
                          torch.tensor(label_list))
dev_dataset = TensorDataset(
                          torch.tensor(dev_list, dtype = torch.int),
                          torch.tensor(dev_label_list))

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
dev_loader = DataLoader(dev_dataset, batch_size=64)
loss_fn = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)



# We need to decide what device we'll be using for our model computations
# The following like says that if any GPU is available, then use it.
# Otherwise, we use a CPU
# device = torch.device(f"cuda" if torch.cuda.is_available() else "cpu")

max_epochs = 10

best_perf_dict = {"metric": math.inf, "epoch": 0}

# Create a randomly initialized model and the optimizer.
# model = MLP(in_dim=16, hid_dim=12, out_dim=7).to(device)
# optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)

# Begin the training loop
for ep in range(1, max_epochs+1):
    print(f"\nEpoch {ep}")
    train_loss = []       # We will use this list to accumulate losses and observe if training is happening

    # We load data in batches from the loader and will do backpropagation
    # for this batch of inputs in every iteration
    for inp, lab in tqdm(train_loader):
        # Switch to train mode
        # This doesn't make a difference to our model but is considered good practice
        # Models might contain layers like Dropout which behave differently when training
        # versus evaluating. This signals these layers to behave appropriately.
        model.train()

        # PyTorch accumulates gradients for every `.backward()`
        # This means if we do not set it to zero, it will add up all the
        # gradients it has seen till that moment.
        optimizer.zero_grad()

        # Let us check what the input and the label shapes are
        # print(f"\nInput shape: {inp.shape}")
        # print(f"Label shape: {lab.shape}")

        out = model(inp.to(device))    #Forward pass
        # print(f"Output shape: {out.shape}")  # Output shape

        # We have the output logits and the labels. We can compute the loss now
        loss = loss_fn(out, lab.to(device))

        # print(f"Loss: {loss} with shape {loss.shape}")

        loss.backward() # computing the gradients
        optimizer.step()  # Performs the optimization

        train_loss.append(loss.cpu().item())    # Appending the batch loss to the list

    print(f"Average training batch loss: {np.mean(train_loss)}")

        # Evaluation Loop
    dev_loss = [] 
    for inp, lab in tqdm(dev_loader):
        # Switch to eval mode
        model.eval()
        # Gradient accumulation is time-consuming
        # It is best to tell torch not to record gradients during evaluation
        # because we don't need it
        with torch.no_grad():
            out = model(inp.to(device))
            preds = out
            new_loss = loss_fn(preds,out)
    dev_loss.append(loss.cpu().item())
    avg_dev_loss = np.mean(dev_loss)        
    print(f"Avg_Dev Loss: {avg_dev_loss }\n")

    # Update the `best_perf_dict` if the best dev performance seen
    # so far is beaten
    if avg_dev_loss  < best_perf_dict["metric"]:
        best_perf_dict["metric"] = avg_dev_loss 
        best_perf_dict["epoch"]  = ep
        torch.save({
            "model_param": model.state_dict(),
            "optim_param": optimizer.state_dict(),
            "dev_metric": avg_dev_loss ,
            "epoch": ep
        }, f"/scratch/general/vast/u1369444/cs6957/assignment1/models/{ep}")




best_epoch = best_perf_dict["epoch"]
model_path = f"/scratch/general/vast/u1369444/cs6957/assignment1/models/{best_epoch}"
checkpoint = torch.load(model_path)

model.load_state_dict(checkpoint["model_param"])
optimizer.load_state_dict(checkpoint["optim_param"])

print(f"""Dev F1 of loaded model: {checkpoint["dev_metric"]} at epoch {checkpoint["epoch"]}""")


def evaluate(loader, model):
    """ Just a method to evaluate a loader w.r.t a model
    Inputs
    --------
    loader: torch.data.DataLoader. Should have a TensorDataset with a tensor for features
              and labels each.
    model: Model. instance of class Model

    Output
    -------
    f1: float. F1 score computed
    """
    # Evaluation Loop
    # gold_labels = []
    # pred_labels = []
    # for inp, lab in tqdm(loader):
    #     # Switch to eval mode
    #     model.eval()
    #     # Gradient accumulation is time-consuming
    #     # It is best to tell torch not to record gradients during evaluation
    #     # because we don't need it
    #     with torch.no_grad():
    #         out = model(inp.to(device))
    #         preds = torch.argmax(out, dim=1)

    #         pred_labels.extend(preds.cpu().tolist())
    #         gold_labels.extend(lab.tolist())

    # f1 = f1_score(gold_labels, pred_labels, average='macro')
    # return f1

    dev_loss = [] 
    for inp, lab in tqdm(dev_loader):
        # Switch to eval mode
        model.eval()
        # Gradient accumulation is time-consuming
        # It is best to tell torch not to record gradients during evaluation
        # because we don't need it
        with torch.no_grad():
            out = model(inp.to(device))
            preds = out
            new_loss = loss_fn(preds,out)
    dev_loss.append(loss.cpu().item())
    avg_dev_loss = np.mean(dev_loss)        
    return avg_dev_loss


# Would like to verify if the model still gives the same F1
# after model has been loaded. This helps identify if there
# are any random seed errors or something bugging which might affect reproducibility
print(f"\nDev F1: {evaluate(dev_loader, model)}\n")
# print(f"\nTest F1: {evaluate(test_loader, model)}\n")



final_weights = list(model.w.parameters())[0].detach().cpu().numpy()
print(final_weights.shape)

file1 = open("/scratch/general/vast/u1369444/cs6957/assignment1/models/embeddings.txt", "w")

L =["18061 100\n"]
for key in word2ix:
  temp = key
  i= word2ix[key]
  for j in range(len(final_weights[i])):
    temp = temp +" "+str(final_weights[i][j])
  temp = temp+"\n"
  L.append(temp)

file1.writelines(L)
file1.close()

