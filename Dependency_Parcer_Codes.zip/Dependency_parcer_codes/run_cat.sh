#!/bin/bash
#SBATCH --account soc-gpu-np
#SBATCH --partition soc-gpu-np
#SBATCH --ntasks-per-node=16
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --time=0:20:00
#SBATCH --mem=32GB
#SBATCH -o assignment_2-%j
#SBATCH --export=ALL
source ~/miniconda3/etc/profile.d/conda.sh
conda activate prasanth
OUT_DIR=/scratch/general/vast/u1369444/cs6957/assignment2/models/concat
mkdir -p ${OUT_DIR}
python nlp_2_concat.py --output_dir ${OUT_DIR}